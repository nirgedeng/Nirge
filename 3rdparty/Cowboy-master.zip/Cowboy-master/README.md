# Cowboy
Cowboy is a C# library for building sockets based services.

- TCP client and server with flexible frame builders.
