﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Cowboy.Sockets")]
[assembly: Guid("39d916fe-2c09-47ab-a5a2-1a23787f20ba")]
