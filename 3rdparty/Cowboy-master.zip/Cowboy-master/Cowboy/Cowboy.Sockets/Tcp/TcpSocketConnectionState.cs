﻿namespace Cowboy.Sockets
{
    public enum TcpSocketConnectionState
    {
        None = 0,
        Connecting = 1,
        Connected = 2,
        Closed = 5,
    }
}
