﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Cowboy.Sockets.Experimental")]
[assembly: Guid("0d6991ef-2781-4185-8b36-80995c9800f3")]
