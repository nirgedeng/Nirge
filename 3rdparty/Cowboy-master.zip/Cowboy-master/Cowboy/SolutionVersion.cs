﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyDescription("Cowboy is a C# library for building sockets based services.")]
[assembly: AssemblyCompany("Dennis Gao")]
[assembly: AssemblyProduct("Cowboy")]
[assembly: AssemblyCopyright("Copyright © 2015-2017 Dennis Gao")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("1.3.14.0")]
[assembly: AssemblyFileVersion("1.3.14.0")]
[assembly: ComVisible(false)]
