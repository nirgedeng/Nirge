﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Cowboy.CommandLines")]
[assembly: Guid("e7a41d23-4f6b-4be2-a311-0d3d25bfe6e7")]
