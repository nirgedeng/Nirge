﻿using System.Threading.Tasks;

namespace Cowboy.TcpLika
{
    internal static class TplExtensions
    {
        public static void Forget(this Task task)
        {
        }
    }
}
