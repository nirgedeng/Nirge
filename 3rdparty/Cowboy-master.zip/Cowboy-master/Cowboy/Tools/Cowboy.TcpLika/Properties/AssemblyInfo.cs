﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Cowboy.TcpLika")]
[assembly: Guid("0ed6cd14-9182-486b-8af3-1d9770449046")]
