﻿#if COREFX
using System;

namespace System.Security
{
    public enum SecurityElementType
    {
        Regular,
        Format,
        Comment
    }
}
#endif