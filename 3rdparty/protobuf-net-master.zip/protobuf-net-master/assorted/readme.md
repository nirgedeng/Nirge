Assorted Stuff
-

This is bits and pieces that were left over when refactoring the build system. Some of these may be perfectly valid and may be moved to /src in due course; some may now be completely redundant and are best ignored (*cough silverlight cough*).